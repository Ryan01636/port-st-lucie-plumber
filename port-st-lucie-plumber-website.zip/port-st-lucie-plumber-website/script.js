// Before publishing, replace this with the company's real email address.
const BUSINESS_EMAIL = "REPLACE_WITH_COMPANY_EMAIL@example.com";

const menuButton = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");
menuButton?.addEventListener("click", () => {
  const open = navLinks.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", String(open));
  menuButton.setAttribute("aria-label", open ? "Close navigation" : "Open navigation");
});
navLinks?.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  navLinks.classList.remove("open");
  menuButton?.setAttribute("aria-expanded", "false");
}));
document.getElementById("year").textContent = new Date().getFullYear();

const form = document.getElementById("contactForm");
const status = document.getElementById("formStatus");
form?.addEventListener("submit", event => {
  event.preventDefault();
  if (!form.reportValidity()) return;
  if (BUSINESS_EMAIL.startsWith("REPLACE_WITH")) {
    status.textContent = "The form is ready, but the company email has not been set yet. Update BUSINESS_EMAIL in script.js before publishing.";
    return;
  }
  const data = new FormData(form);
  const subject = encodeURIComponent(`Plumbing service request — ${data.get("service")}`);
  const body = encodeURIComponent(
    `Name: ${data.get("name")}\nEmail: ${data.get("email")}\nPhone: ${data.get("phone") || "Not provided"}\nService: ${data.get("service")}\n\nDetails:\n${data.get("message")}`
  );
  window.location.href = `mailto:${BUSINESS_EMAIL}?subject=${subject}&body=${body}`;
  status.textContent = "Your email app should open with the request prepared. Please send it to complete the request.";
});
