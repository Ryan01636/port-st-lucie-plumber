PORT ST. LUCIE PLUMBER & DRAIN CLEANING CO. — WEBSITE DRAFT

Files:
- index.html: website content and sections
- styles.css: responsive layout and visual design
- script.js: mobile navigation and contact form behavior

IMPORTANT BEFORE PUBLISHING
1. Confirm the company is authorized to use this name and the supplied reviews.
2. In script.js, replace REPLACE_WITH_COMPANY_EMAIL@example.com with the real company email.
3. Add the real phone number, business hours, license/insurance details (if applicable), and any verified service areas if desired.
4. The review rating/count and quotations were based on information supplied by the requester. Verify these and link to the official Google profile before launch.
5. The contact form uses the visitor's email app (mailto); it does not store or send form data by itself.
6. Check domain availability before purchasing a custom domain. Suggested name: PortStLuciePlumber.com, if available.
